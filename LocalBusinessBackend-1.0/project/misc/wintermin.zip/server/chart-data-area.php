<?php

$data=array(
  array(
     'label' => 'Recurrent',
     'color' => '#745fa4',
     'data' => 
    array(
      array('Mar', 125),
      array('Apr', 148),
      array('May', 42),
      array('Jun', 115),
      array('Jul', 45),
      array('Aug', 77),
      array('Sep', 59)
    )
  ),
  array(
     'label' => 'Uniques',
     'color' => '#58a7e2',
     'data' => 
    array(
      array('Mar', 60),
      array('Apr', 20),
      array('May', 79),
      array('Jun', 30),
      array('Jul', 55),
      array('Aug', 124),
      array('Sep', 29)
    )
  )
);

?>