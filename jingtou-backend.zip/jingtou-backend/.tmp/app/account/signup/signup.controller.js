'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var SignupController = (function () {
  //end-non-standard

  function SignupController(Auth, $state) {
    _classCallCheck(this, SignupController);

    this.user = {};
    this.error = {};
    this.submitted = false;

    this.Auth = Auth;
    this.$state = $state;
    this.registering = false;
  }

  _createClass(SignupController, [{
    key: 'register',
    value: function register(form) {
      var _this = this;

      this.submitted = true;

      if (form.$valid) {
        this.registering = true;
        this.Auth.createUser({
          loginId: this.user.loginId,
          // email: this.user.email,
          password: this.user.password
        }).then(function () {
          // Account created, redirect to home
          _this.$state.go('pc.dashboard');
        })['catch'](function (err) {
          _this.registering = false;
          // err = err.data;
          if (err.name) {
            _this.error.name = err.name;
            _this.error.message = err.message;
          }

          // Update validity of form fields that match the sequelize errors
          // if (err.name) {
          //   angular.forEach(err.fields, field => {
          //     form[field].$setValidity('mongoose', false);
          //     this.errors[field] = err.message;
          //   });
          // }
        });
      }
    }
  }]);

  return SignupController;
})();

angular.module('billynApp').controller('SignupController', SignupController);

//start-non-standard
//# sourceMappingURL=signup.controller.js.map
