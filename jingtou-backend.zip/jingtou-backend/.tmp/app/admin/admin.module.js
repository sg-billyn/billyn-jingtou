'use strict';

angular.module('billynApp.admin', ['billynApp.auth', 'ui.router']);
//# sourceMappingURL=admin.module.js.map
