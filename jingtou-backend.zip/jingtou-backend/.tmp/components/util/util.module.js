'use strict';

angular.module('billynApp.util', []);
//# sourceMappingURL=util.module.js.map
