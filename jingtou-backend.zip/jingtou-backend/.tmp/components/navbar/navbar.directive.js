'use strict';

angular.module('billynApp').directive('navbar', function () {
  return {
    templateUrl: 'components/navbar/view/navbar.html',
    restrict: 'E',
    controller: 'NavbarController',
    controllerAs: 'nav'
  };
});
//# sourceMappingURL=navbar.directive.js.map
