'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

(function () {
    var CollabController = function CollabController($state, $stateParams, $rootScope, BNut) {
        _classCallCheck(this, CollabController);

        var test = 'test';
    };

    var CollabHomeController = function CollabHomeController($state, $stateParams, $rootScope, BNut, BCollab) {
        _classCallCheck(this, CollabHomeController);

        var ctrl = this;
        this.nut = $rootScope.current.nut;

        this.isLocalCollab = function (collab) {
            return angular.isObject(collab.userNutPermits);
        };
    };

    var AdminCollabController = function AdminCollabController($rootScope, BCollab) {
        _classCallCheck(this, AdminCollabController);

        var ctrl = this;

        BCollab.findAll({
            spaceId: $rootScope.current.space._id
        }).then(function (collabs) {
            ctrl.collabs = collabs;
        });
    };

    var CreateCollabController = (function () {
        function CreateCollabController($state, BCollab, $http, $rootScope) {
            _classCallCheck(this, CreateCollabController);

            var that = this;

            //layoutService.breadcrumbs.push({state:'user.createSpace', text:'创建机构'});

            // 暂存依赖
            this.$state = $state;
            this.BCollab = BCollab;
            this.creating = false;
            this.current = $rootScope.current;
            this.roles = $rootScope.current.space.roles.slice();

            this.collab = {
                name: '', alias: '', description: '', type: 'normal'
            };

            $http.get("/components/blyn/core/collab/config.json").then(function (result) {
                //set default type
                that.collabTypes = result.data.types;
            });
        }

        _createClass(CreateCollabController, [{
            key: 'createCollab',
            value: function createCollab(form) {
                var that = this;
                if (form.$valid) {
                    this.creating = true;
                    // 暂存this对象
                    var ctrl = this;
                    // 将collab据，写进数据库！
                    //get all collab data from config
                    this.collab.type = this.collabTypes[this.collab.type];
                    this.collab.spaceId = this.current.space._id;
                    var parentRoles = [];
                    this.roles.forEach(function (r) {
                        if (r.selected) {
                            parentRoles.push({
                                parentRoleId: r._id
                            });
                        }
                    });
                    var inputRole = this.inputRole || null;

                    if (angular.isObject(inputRole)) {
                        parentRoles.push(inputRole);
                    }
                    if (parentRoles.length > 0) {
                        this.collab.parentRoles = parentRoles;
                    }
                    this.BCollab.createCollab(this.collab).then(function (res) {
                        that.$state.go('pc.space.app.collab.adminCollab');
                    }, function (err) {
                        that.creating = false;
                        console.log('err:', err);
                    });
                }
            }
        }]);

        return CreateCollabController;
    })();

    var ParentCollabController = function ParentCollabController($state, $stateParams, $rootScope, BCollab) {
        _classCallCheck(this, ParentCollabController);

        var ctrl = this;
        ctrl.current = $rootScope.current;

        BCollab.findAllJoinableSpace().then(function (spaces) {
            ctrl.joinableSpaces = spaces;
        });

        BCollab.findAllJoinedSpace().then(function (spaces) {
            ctrl.joinedSpaces = spaces;
        });

        this.isJoinedCollab = function (collab, space) {
            var joinedCollabs = space.joinedCollabs;
            var isJoined = false;
            joinedCollabs.forEach(function (jc) {
                if (jc._id === collab._id) {
                    isJoined = true;
                }
            });
            return isJoined;
        };
    };

    var JoinCollabController = (function () {
        function JoinCollabController($state, $stateParams, $rootScope, BCollab) {
            _classCallCheck(this, JoinCollabController);

            var ctrl = this;
            this.$state = $state;
            ctrl.current = $rootScope.current;
            this.collabRole = {};
            this.roles = this.current.space.roles;
            this.BCollab = BCollab;

            if ($stateParams.collabId) {
                BCollab.find($stateParams.collabId).then(function (collab) {
                    $rootScope.current.collab = collab;
                    ctrl.current.collab = collab;
                });
            }
        }

        _createClass(JoinCollabController, [{
            key: 'joinCollab',
            value: function joinCollab(form) {
                var that = this;
                if (form.$valid) {
                    this.creating = true;
                    // 暂存this对象
                    var ctrl = this;

                    var collabRoleData = [];

                    this.roles.forEach(function (r) {
                        if (r.selected) {
                            var collabRole = {};
                            collabRole.collabId = that.current.collab._id;
                            collabRole.childRoleId = r._id;
                            collabRoleData.push(collabRole);
                        }
                    });
                    var inputRole = this.inputRole || null;

                    if (angular.isObject(inputRole)) {
                        var collabRole = {};
                        collabRole.childRole = inputRole;
                        collabRole.spaceId = that.current.space._id;
                        collabRole.collabId = that.current.collab._id;
                        collabRoleData.push(collabRole);
                    }

                    this.BCollab.bulkAddCollabRole(collabRoleData).then(function (res) {
                        ctrl.$state.go('pc.space.app.collab.parentCollabs');
                    }, function (err) {
                        that.creating = false;
                        console.log('err:', err);
                    });
                }
            }
        }]);

        return JoinCollabController;
    })();

    var ChildCollabController = function ChildCollabController($state, $stateParams, $rootScope, BNut) {
        _classCallCheck(this, ChildCollabController);

        var test = 'test';
    };

    var CollabNutController = function CollabNutController($state, $stateParams, $rootScope, BCollab) {
        _classCallCheck(this, CollabNutController);

        var ctrl = this;
        BCollab.findAllUserCollabNut().then(function (spaces) {
            ctrl.spaces = spaces;
        });
    };

    angular.module('billynApp.core').controller('CollabController', CollabController).controller('CollabHomeController', CollabHomeController).controller('AdminCollabController', AdminCollabController).controller('CreateCollabController', CreateCollabController).controller('ParentCollabController', ParentCollabController).controller('JoinCollabController', JoinCollabController).controller('CollabNutController', CollabNutController).controller('ChildCollabController', ChildCollabController);
})();
//# sourceMappingURL=collab.controllers.js.map
