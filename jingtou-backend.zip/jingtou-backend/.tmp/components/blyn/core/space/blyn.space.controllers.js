'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

(function () {
  var SpaceController = function SpaceController() {
    _classCallCheck(this, SpaceController);
  }

  /*class SpaceHomeController {
    constructor($rootScope, BApp) {
      var ctrl = this;
      this.space = $rootScope.current.space;
      BApp.findAppsByUser(this.space._id).then(function (apps) {
          ctrl.space.apps = [];
          for (var key in apps) {
              ctrl.space.apps.push(apps[key]);
          }
      });
    }
  }*/

  ;

  var SpaceHomeController = function SpaceHomeController($state, $stateParams, $rootScope, BNut) {
    _classCallCheck(this, SpaceHomeController);

    var ctrl = this;
    ctrl.space = $rootScope.current.space;
    /*
    $rootScope.current.nut.permits = [];
    BNut.findAllUserPermitNut($rootScope.current.app._id).then(function (permitNuts) {
      for (var i = 0; i < permitNuts.length; i++) {
        if (permitNuts[i].nut && permitNuts[i].nut.name == 'space') {
          $rootScope.current.nut.permits.push(permitNuts[i].permit);
          ctrl.nut = $rootScope.current.nut;
        }
      }
    });*/
  };

  var AppStoreController = function AppStoreController($state) {
    _classCallCheck(this, AppStoreController);

    // Init the switch button group.
    if (/^pc\.space\.appStore\.add/.test($state.current.name)) {
      this.tab = 'add';
    } else {
      this.tab = 'delete';
    }
  };

  var AddAppsController = function AddAppsController(BApp) {
    _classCallCheck(this, AddAppsController);

    var self = this;
    BApp.findAppsInStore().then(function (apps) {
      //console.log('apps', apps);
      self.apps = apps;
    }, function (err) {
      console.log('err', err);
    });
  };

  var DeleteAppController = function DeleteAppController(BSpace, BApp, $q) {
    _classCallCheck(this, DeleteAppController);

    var self = this;
    $q.when(BApp.findAppsInSpace()).then(function (apps) {
      self.apps = apps ? apps : [];
    }, function (err) {
      console.log('err', err);
    });
  };

  angular.module('billynApp.core').controller('SpaceController', SpaceController).controller('SpaceHomeController', SpaceHomeController).controller('AppStoreController', AppStoreController).controller('AddAppsController', AddAppsController).controller('DeleteAppController', DeleteAppController);
})();
//# sourceMappingURL=blyn.space.controllers.js.map
