'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

(function () {
    var RoleController = function RoleController($state, $stateParams, $rootScope, permitNut) {
        _classCallCheck(this, RoleController);
    };

    // Get user role in current nut.
    // var role = permitNut.role.name;
    // if ($state.is('pc.space.app.role') || !$state.includes('pc.space.app.role.' + role)) {
    //     // If current state just equal to 'pc.space.app.role' or not under 'pc.space.app.role'+role,
    //     // we'll go to the right role home page.
    //     $state.go('pc.space.app.role.' + role);
    // }

    var RoleHomeController = function RoleHomeController($state, $stateParams, $rootScope, BNut) {
        _classCallCheck(this, RoleHomeController);

        var ctrl = this;
        $rootScope.current.nut.permits = [];
        BNut.findAllUserPermitNut($rootScope.current.app._id).then(function (permitNuts) {
            for (var i = 0; i < permitNuts.length; i++) {
                if (permitNuts[i].nut && permitNuts[i].nut.name == 'role') {
                    $rootScope.current.nut.permits.push(permitNuts[i].permit);
                    ctrl.nut = $rootScope.current.nut;
                }
            }
        });

        this.getStateByPermit = function (permitName) {
            return 'pc.space.app.role.' + permitName.replace(/\./g, "_");
        };

        this.createCircle = function (formData) {
            BCircle.addCircle(formData);
        };
    };

    var RoleAdminController = function RoleAdminController() {
        _classCallCheck(this, RoleAdminController);
    };

    var RoleAdminHomeController = function RoleAdminHomeController($stateParams, BRole) {
        _classCallCheck(this, RoleAdminHomeController);

        this.deletingRole = {};
        var spaceId = $stateParams.spaceId;
        var ctrl = this;
        this.BRole = BRole;
        this.adminRoles = [];
        this.memberRoles = [];
        this.customerRoles = [];
        this.BRole.getSpaceRoles(spaceId).then(function (data) {
            angular.forEach(data, function (role) {
                console.log(role);
                if (role.fullname.indexOf("root.admin") == 0) {
                    ctrl.adminRoles.push(role);
                } else if (role.fullname.indexOf("root.member") == 0) {
                    ctrl.memberRoles.push(role);
                } else if (role.fullname.indexOf("root.customer") == 0) {
                    ctrl.customerRoles.push(role);
                }
            });
        });
    };

    var AdminSpaceRoleController = (function () {
        function AdminSpaceRoleController($stateParams, $state, BRole, toaster) {
            _classCallCheck(this, AdminSpaceRoleController);

            // alert("Space Role Cotroller");
            this.currentRole = {};
            this.newRole = {};
            this.toaster = toaster;
            this.$state = $state;
            var spaceId = $stateParams.spaceId;
            var ctrl = this;
            this.BRole = BRole;
            this.adminRoles = [];
            this.memberRoles = [];
            this.customerRoles = [];
            this.BRole.getSpaceRoles(spaceId).then(function (data) {
                angular.forEach(data, function (role) {
                    console.log(role);
                    if (role.fullname.indexOf("root.role.admin") == 0) {
                        ctrl.adminRoles.push(role);
                    } else if (role.fullname.indexOf("root.role.member") == 0) {
                        ctrl.memberRoles.push(role);
                    } else if (role.fullname.indexOf("root.role.customer") == 0) {
                        ctrl.customerRoles.push(role);
                    }
                });
            });
        }

        _createClass(AdminSpaceRoleController, [{
            key: 'save',
            value: function save() {
                var newRole = {};
                newRole.spaceId = this.currentRole.spaceId;
                newRole.parent = this.currentRole._id;
                newRole.name = this.newRole.name;
                newRole.alias = this.newRole.alias;
                var ctrl = this;
                angular.element('#addRoleModal').on('hidden.bs.modal', function () {
                    ctrl.$state.reload();
                });
                this.BRole.addChild(ctrl.currentRole._id, newRole).then(function (res) {
                    ctrl.toaster.success("Success add role");
                });
            }
        }, {
            key: 'delete',
            value: function _delete() {
                var ctrl = this;
                angular.element('#deleteRoleModal').on('hidden.bs.modal', function () {
                    ctrl.$state.reload();
                });
                this.BRole.deleteRole(ctrl.currentRole._id).then(function (res) {
                    ctrl.toaster.success("Success delete role");
                });
            }
        }]);

        return AdminSpaceRoleController;
    })();

    var AdminUserRoleController = (function () {
        function AdminUserRoleController($stateParams, $state, BRole, BSpace) {
            _classCallCheck(this, AdminUserRoleController);

            this.BRole = BRole;
            this.BSpace = BSpace;
            this.spaceId = $stateParams.spaceId;
            this.$state = $state;
            this.spaceRoles = [];
            this.spaceUsers = [];
            this.currentUser = {};
            this.roles = [];
            var ctrl = this;

            ctrl.BRole.getSpaceRoles(ctrl.spaceId).then(function (data) {
                ctrl.spaceRoles = data;
            });

            ctrl.BSpace.getSpaceUsers(this.spaceId).then(function (data) {
                data.forEach(function (spaceUser) {
                    var a = spaceUser.roles;
                    spaceUser.roles = a.filter(function (role) {
                        return role.spaceId == ctrl.spaceId;
                    });
                });

                ctrl.spaceUsers = data.filter(function (spaceUser) {
                    return spaceUser.roles.length > 0;
                });
            });
        }

        //class

        _createClass(AdminUserRoleController, [{
            key: 'startDialog',
            value: function startDialog(user) {
                console.log("mouse dowm");

                this.currentUser = user;
                this.roles = [];

                var ctrl = this;

                ctrl.spaceRoles.forEach(function (role) {
                    var enabled = false;
                    var index = ctrl.currentUser.roles.findIndex(function (r) {
                        return r._id == role._id;
                    });

                    if (index > -1) enabled = true;

                    role.checked = enabled;
                    ctrl.roles.push(role);
                });

                console.log("total roles = " + ctrl.roles);
            }
        }, {
            key: 'assignRole',
            value: function assignRole() {

                var ctrl = this;
                var toAdd = [];
                var toDel = [];

                this.roles.forEach(function (role) {
                    var index = ctrl.currentUser.roles.findIndex(function (r) {
                        return r._id == role._id;
                    });
                    if (role.checked) {
                        if (index == -1) {
                            //add if not find in user roles bu checked
                            toAdd.push(role);
                        }
                    } else {
                        if (index > -1) {
                            //delete if find in user roles but unchecked
                            toDel.push(role);
                        }
                    }
                });
                if (toAdd.length > 0) {
                    angular.element('#assignRoleModal').on('hidden.bs.modal', function () {
                        ctrl.$state.reload();
                    });

                    var toAddRoles = [];
                    toAdd.forEach(function (role) {
                        var roleData = {};
                        roleData.userId = ctrl.currentUser._id;
                        roleData.roleId = role._id;

                        toAddRoles.push(roleData);
                    });
                    ctrl.BRole.addUserRoleBatch(toAddRoles).then(function (res) {
                        ctrl.toaster.success("Success add roles");
                    });
                }
                if (toDel.length > 0) {
                    angular.element('#assignRoleModal').on('hidden.bs.modal', function () {
                        ctrl.$state.reload(); //.go('pc.joinSpace', null, { reload: true });
                    });

                    // toDelRoles = toDel.map(function (role) {
                    //   var roleData = {};
                    //   roleData.userId = ctrl.user._id;
                    //   roleData.spaceId = ctrl.spaceId;
                    //   roleData.roleId = role._id;

                    //   return ctrl.BRole.deleteUserRole(roleData);
                    // });
                    // ctrl.$q.all(toDelRoles).then(function (res) {
                    //   var a = res;
                    //   var b = a.length;
                    // });
                }

                //  ctrl.$state.go('user');//reload();
            }
            //method

        }, {
            key: 'getLabelClassByRole',
            value: function getLabelClassByRole(role) {
                var rolesArr = role.split('.');
                if (typeof rolesArr[0] == 'undefined') {
                    return 'label-info';
                }
                switch (rolesArr[0]) {
                    case 'admin':
                        return 'label-danger';
                    case 'member':
                        return 'label-warning';
                    case 'customer':
                        return 'label-success';
                    default:
                        return 'label-info';
                }
            }
        }]);

        return AdminUserRoleController;
    })();

    var RoleAdminAddRoleController = (function () {
        function RoleAdminAddRoleController($stateParams, BRole, toaster) {
            _classCallCheck(this, RoleAdminAddRoleController);

            this.toaster = toaster;
            this.BRole = BRole;
            this.role = $stateParams.parent;
            this.name = this.role.name;
            this.alias = this.role.alias;
        }

        _createClass(RoleAdminAddRoleController, [{
            key: 'save',
            value: function save() {
                var newRole = {};
                newRole.spaceId = this.role.spaceId;
                newRole.parent = this.role._id;
                newRole.name = this.name;
                newRole.alias = this.alias;
                var ctrl = this;

                this.BRole.addChild(this.role._id, newRole).then(function (res) {
                    if (res.$resolved) {
                        ctrl.toaster.success("成功添加角色：" + res.alias);
                    } else {
                        ctrl.toaster.error("添加加色失败.");
                    }
                });
            }
        }]);

        return RoleAdminAddRoleController;
    })();

    var SpaceRoleController = (function () {
        function SpaceRoleController($stateParams, $state, BRole, toaster) {
            _classCallCheck(this, SpaceRoleController);

            // alert("Space Role Cotroller");
            this.currentRole = {};
            this.newRole = {};
            this.toaster = toaster;
            this.$state = $state;
            var spaceId = $stateParams.spaceId;
            var ctrl = this;
            this.BRole = BRole;
            this.adminRoles = [];
            this.memberRoles = [];
            this.customerRoles = [];
            this.BRole.getSpaceRoles(spaceId).then(function (data) {
                angular.forEach(data, function (role) {
                    console.log(role);
                    if (role.fullname.indexOf("root.role.admin") == 0) {
                        ctrl.adminRoles.push(role);
                    } else if (role.fullname.indexOf("root.role.member") == 0) {
                        ctrl.memberRoles.push(role);
                    } else if (role.fullname.indexOf("root.role.customer") == 0) {
                        ctrl.customerRoles.push(role);
                    }
                });
            });
        }

        _createClass(SpaceRoleController, [{
            key: 'save',
            value: function save() {
                var newRole = {};
                newRole.spaceId = this.currentRole.spaceId;
                newRole.parent = this.currentRole._id;
                newRole.name = this.newRole.name;
                newRole.alias = this.newRole.alias;
                var ctrl = this;
                angular.element('#addRoleModal').on('hidden.bs.modal', function () {
                    ctrl.$state.reload();
                });
                this.BRole.addChild(ctrl.currentRole._id, newRole).then(function (res) {
                    ctrl.toaster.success("Success add role");
                });
            }
        }, {
            key: 'delete',
            value: function _delete() {
                var ctrl = this;
                angular.element('#deleteRoleModal').on('hidden.bs.modal', function () {
                    ctrl.$state.reload();
                });
                this.BRole.deleteRole(ctrl.currentRole._id).then(function (res) {
                    ctrl.toaster.success("Success delete role");
                });
            }
        }]);

        return SpaceRoleController;
    })();

    var UserRoleController = (function () {
        function UserRoleController($stateParams, $state, BRole, BSpace) {
            _classCallCheck(this, UserRoleController);

            this.BRole = BRole;
            this.BSpace = BSpace;
            this.spaceId = $stateParams.spaceId;
            this.$state = $state;
            this.spaceRoles = [];
            this.spaceUsers = [];
            this.currentUser = {};
            this.roles = [];
            var ctrl = this;

            ctrl.BRole.getSpaceRoles(ctrl.spaceId).then(function (data) {
                ctrl.spaceRoles = data;
            });

            ctrl.BSpace.getSpaceUsers(this.spaceId).then(function (data) {
                data.forEach(function (spaceUser) {
                    var a = spaceUser.roles;
                    spaceUser.roles = a.filter(function (role) {
                        return role.spaceId == ctrl.spaceId;
                    });
                });

                ctrl.spaceUsers = data.filter(function (spaceUser) {
                    return spaceUser.roles.length > 0;
                });
            });
        }

        //class

        _createClass(UserRoleController, [{
            key: 'startDialog',
            value: function startDialog(user) {
                console.log("mouse dowm");

                this.currentUser = user;

                var ctrl = this;

                ctrl.spaceRoles.forEach(function (role) {
                    var enabled = false;
                    var index = ctrl.currentUser.roles.findIndex(function (r) {
                        return r._id == role._id;
                    });

                    if (index > -1) enabled = true;

                    role.checked = enabled;
                    ctrl.roles.push(role);
                });

                console.log("total roles = " + ctrl.roles);
            }
        }, {
            key: 'assignRole',
            value: function assignRole() {

                var ctrl = this;
                var toAdd = [];
                var toDel = [];

                this.roles.forEach(function (role) {
                    var index = ctrl.currentUser.roles.findIndex(function (r) {
                        return r._id == role._id;
                    });
                    if (role.checked) {
                        if (index == -1) {
                            //add if not find in user roles bu checked
                            toAdd.push(role);
                        }
                    } else {
                        if (index > -1) {
                            //delete if find in user roles but unchecked
                            toDel.push(role);
                        }
                    }
                });
                if (toAdd.length > 0) {
                    angular.element('#assignRoleModal').on('hidden.bs.modal', function () {
                        ctrl.$state.reload();
                    });

                    var toAddRoles = [];
                    toAdd.forEach(function (role) {
                        var roleData = {};
                        roleData.userId = ctrl.currentUser._id;
                        roleData.roleId = role._id;

                        toAddRoles.push(roleData);
                    });
                    ctrl.BRole.addUserRoleBatch(toAddRoles).then(function (res) {
                        ctrl.toaster.success("Success add roles");
                    });
                }
                if (toDel.length > 0) {
                    angular.element('#assignRoleModal').on('hidden.bs.modal', function () {
                        ctrl.$state.reload(); //.go('pc.joinSpace', null, { reload: true });
                    });

                    // toDelRoles = toDel.map(function (role) {
                    //   var roleData = {};
                    //   roleData.userId = ctrl.user._id;
                    //   roleData.spaceId = ctrl.spaceId;
                    //   roleData.roleId = role._id;

                    //   return ctrl.BRole.deleteUserRole(roleData);
                    // });
                    // ctrl.$q.all(toDelRoles).then(function (res) {
                    //   var a = res;
                    //   var b = a.length;
                    // });
                }

                //  ctrl.$state.go('user');//reload();
            }
            //method

        }]);

        return UserRoleController;
    })();

    angular.module('billynApp.core').controller('RoleController', RoleController).controller('RoleHomeController', RoleHomeController).controller('AdminSpaceRoleController', AdminSpaceRoleController).controller('AdminUserRoleController', AdminUserRoleController);
})();

// .controller('SpaceRoleController', SpaceRoleController)
// .controller('UserRoleController', UserRoleController)
// .controller('RoleAdminController', RoleAdminController)
// .controller('RoleAdminHomeController', RoleAdminHomeController)
// .controller('RoleAdminAddRoleController', RoleAdminAddRoleController)
//# sourceMappingURL=blyn.role.controllers.js.map
