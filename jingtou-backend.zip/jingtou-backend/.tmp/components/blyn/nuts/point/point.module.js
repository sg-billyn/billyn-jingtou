'use strict';

angular.module('blyn.nut.point', ['billynApp.util', 'ngCookies', 'ui.router']);
//# sourceMappingURL=point.module.js.map
