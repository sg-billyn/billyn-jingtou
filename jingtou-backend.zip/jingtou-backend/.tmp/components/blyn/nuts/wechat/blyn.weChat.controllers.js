'use strict';

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

(function () {
  var WeChatHomeController = function WeChatHomeController() {
    _classCallCheck(this, WeChatHomeController);
  };

  var ConfigController = (function () {
    function ConfigController($state, WeChatService) {
      _classCallCheck(this, ConfigController);

      this.$state = $state;
      this.WeChatService = WeChatService;
      this.types = [{ value: 'authService', name: '认证服务号' }, { value: 'authSubscribe', name: '认证订阅号' }, { value: 'commonService', name: '普通服务号' }, { value: 'commonSubscribe', name: '普通订阅号' }];
    }

    _createClass(ConfigController, [{
      key: 'save',
      value: function save(weChatData) {
        this.WeChatService.weChatData = new Array();
        this.WeChatService.weChatData.push(weChatData);
        this.$state.go('weChat.config');
      }
    }]);

    return ConfigController;
  })();

  var MenuController = (function () {
    function MenuController($state, WeChatService) {
      _classCallCheck(this, MenuController);

      this.$state = $state;
      this.WeChatService = WeChatService;
    }

    _createClass(MenuController, [{
      key: 'save',
      value: function save(menuData) {
        this.WeChatService.menuData = new Array();
        this.WeChatService.menuData.push(menuData);
        this.$state.go('weChat.menu');
      }
    }]);

    return MenuController;
  })();

  var KeyWordsController = (function () {
    function KeyWordsController($state, WeChatService) {
      _classCallCheck(this, KeyWordsController);

      this.$state = $state;
      this.WeChatService = WeChatService;
    }

    _createClass(KeyWordsController, [{
      key: 'saveSingle',
      value: function saveSingle(singleData) {
        this.WeChatService.singleData = new Array();
        this.WeChatService.singleData.push(singleData);
        this.$state.go('weChat.keyWord.single');
      }
    }, {
      key: 'saveMult',
      value: function saveMult(multData) {
        this.WeChatService.multData = new Array();
        this.WeChatService.multData.push(multData);
        this.$state.go('weChat.keyWord.mult');
      }
    }, {
      key: 'saveText',
      value: function saveText(textData) {
        this.WeChatService.textData = new Array();
        this.WeChatService.textData.push(textData);
        this.$state.go('weChat.keyWord.text');
      }
    }]);

    return KeyWordsController;
  })();

  var MassController = (function () {
    function MassController($state, WeChatService) {
      _classCallCheck(this, MassController);

      this.$state = $state;
      this.WeChatService = WeChatService;
    }

    _createClass(MassController, [{
      key: 'save',
      value: function save(massData) {
        this.WeChatService.massData = new Array();
        this.WeChatService.massData.push(massData);
        this.$state.go('weChat.mass');
      }
    }]);

    return MassController;
  })();

  var SiteController = (function () {
    function SiteController($state, WeChatService) {
      _classCallCheck(this, SiteController);

      this.$state = $state;
      this.WeChatService = WeChatService;
    }

    _createClass(SiteController, [{
      key: 'saveCategory',
      value: function saveCategory(categoryData) {
        this.WeChatService.categoryData = new Array();
        this.WeChatService.categoryData.push(categoryData);
        this.$state.go('weChat.site.category');
      }
    }, {
      key: 'saveSlide',
      value: function saveSlide(slideData) {
        this.WeChatService.slideData = new Array();
        this.WeChatService.slideData.push(slideData);
        this.$state.go('weChat.site.slide');
      }
    }, {
      key: 'saveText',
      value: function saveText(textData) {
        this.WeChatService.textData = new Array();
        this.WeChatService.textData.push(textData);
        this.$state.go('weChat.site.template');
      }
    }]);

    return SiteController;
  })();

  angular.module('billynApp').controller('WeChatHomeController', WeChatHomeController).controller('ConfigController', ConfigController).controller('MenuController', MenuController).controller('KeyWordsController', KeyWordsController).controller('MassController', MassController).controller('SiteController', SiteController);
})();
//# sourceMappingURL=blyn.weChat.controllers.js.map
