'use strict';

angular.module('billynApp.nut', ['billynApp.auth', 'billynApp.util', 'billynApp.core', 'ngCookies', 'ui.router', 'ngAnimate', 'ui.bootstrap', 'ncy-angular-breadcrumb']);
//# sourceMappingURL=blyn.nut.module.js.map
