'use strict';

angular.module('blyn.nut.voucher', ['billynApp.util', 'ngCookies', 'ui.router']);
//# sourceMappingURL=blyn.core.module.js.map
