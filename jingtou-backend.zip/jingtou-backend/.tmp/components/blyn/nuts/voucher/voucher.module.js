'use strict';

angular.module('billynApp.nut.voucher', ['billynApp.util', 'ngCookies', 'ui.router']);
//# sourceMappingURL=voucher.module.js.map
