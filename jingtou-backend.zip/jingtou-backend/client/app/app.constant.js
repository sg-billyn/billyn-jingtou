(function(angular, undefined) {
'use strict';

angular.module('billynApp.constants', [])

.constant('appConfig', {userRoles:['guest','user','admin']})

;
})(angular);