'use strict';

angular.module('billynApp.util', []);
