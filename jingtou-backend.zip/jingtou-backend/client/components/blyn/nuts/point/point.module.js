'use strict';

angular.module('blyn.nut.point', [
  'billynApp.util',
  'ngCookies',
  'ui.router'
])
