'use strict';

angular.module('billynApp.nut.voucher', [
  'billynApp.util',
  'ngCookies',
  'ui.router'
])
